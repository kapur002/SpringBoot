package com.in28minutes.rest.webservices.rws.helloworld;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorldController {

	@RequestMapping(method=RequestMethod.GET, path="/helloworld")
	public String helloWorld() {
		return "Hello World 2";
	}
	
	@GetMapping(path="/hello-world-bean")
	public HelloWorldBean helloWorldBean() {
		return new HelloWorldBean("Hello World");
	}
	
	@GetMapping(path="/hello-parth-bean")
	public HelloParthBean helloParthBean() {
		return new HelloParthBean("Hello Parth");
	}
	
	@GetMapping(path="/hello-rajeev-bean")
	public HelloRajeevBean helloRajeevBean() {
		return new HelloRajeevBean("Hello Rajeev");
	}
	
	@GetMapping(path="hello-world/urlpart2/{id}")
	public HelloWorldBean helloWorldPathVariable(@PathVariable String id) {
		return new HelloWorldBean(String.format("Hello World, %s", id));
	}
}
